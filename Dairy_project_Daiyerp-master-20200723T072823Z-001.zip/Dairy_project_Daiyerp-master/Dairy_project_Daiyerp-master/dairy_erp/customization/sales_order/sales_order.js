
frappe.ui.form.on("Sales Order", {
	
});

$.extend(cur_frm.cscript, new dairy.price_list.PriceListController({frm: cur_frm}));