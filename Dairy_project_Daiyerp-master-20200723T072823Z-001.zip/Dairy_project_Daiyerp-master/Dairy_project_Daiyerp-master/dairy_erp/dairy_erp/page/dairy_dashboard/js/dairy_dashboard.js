function myFunction() {
    alert( 'Hello, world!' );              // The function returns the product of p1 and p2
}