// Copyright (c) 2018, Stellapps Technologies Private Ltd.
// For license information, please see license.txt

frappe.ui.form.on('Mobile App Log', {
	refresh: function(frm) {

	}
});
