// Copyright (c) 2018, Stellapps Technologies Private Ltd.
// For license information, please see license.txt

frappe.ui.form.on('FMCR Table', {
	refresh: function(frm) {

	}
});
