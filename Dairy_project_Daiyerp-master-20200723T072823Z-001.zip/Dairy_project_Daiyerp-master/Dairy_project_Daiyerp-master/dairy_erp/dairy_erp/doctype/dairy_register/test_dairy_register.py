# -*- coding: utf-8 -*-
# Copyright (c) 2018, Stellapps Technologies Private Ltd.
# See license.txt
from __future__ import unicode_literals

import frappe
import unittest

class TestDairyRegister(unittest.TestCase):
	pass
